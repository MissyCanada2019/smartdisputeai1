# frozen_string_literal: true

module Stripe
  class RecipientTransfer < StripeObject
    OBJECT_NAME = "recipient_transfer"
  end
end
