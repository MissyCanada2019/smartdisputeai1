# frozen_string_literal: true

module Stripe
  VERSION = "14.0.0"
end
